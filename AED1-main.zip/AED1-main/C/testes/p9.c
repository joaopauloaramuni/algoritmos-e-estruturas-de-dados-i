//853355_AED1

#include "io.h"

int main (void)
{
    apresentacao("teste");

    pause("Aperte <ENTER> para sair.");
    return(0);
}